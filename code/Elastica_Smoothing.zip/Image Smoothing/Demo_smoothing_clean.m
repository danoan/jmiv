% This is a main demo for our new algorithm to solve 
% Euler's Elastica Model. 
% L.-J. Deng (UESTC); liangjian.deng@uestc.edu.cn; Time: 2018-09-18
% Code link: http://www.escience.cn/people/dengliangjian/codes.html

% Our Elastica code for smoothing: 
% Reproducible code for all examples in Fig.5 of the manuscript.
% Note that: If 1) lena image, tol = 3e-5 (line 40); otherwise, tol = 1e-5
%               2) all images with noise std = 10 (line 38)
%               3) for display, If change input image, please replace the
%                  corresponding zooming in locations (line 60-62)
%===============================
clear; close all;
addpath('Functions', 'TestImg');

%% =====Generate Noisy Image======
profile on
data.randseed        = 12345;
% read images: select one img from the folder, or you can add your img into
% the folder for test
[filename, filepath, FilterIndex ] = uigetfile('TestImg/*.*','Read image');
temp_uclean =  double(imread(fullfile(filepath,filename)));

% Four examples in Fig.5 in the manuscript: ball.bmp; star.bmp; square.bmp; 
if strcmp(filename, 'lena.pgm')
    para.tol         = 3e-5; 
else
    para.tol         = 1e-5; 
end

% add noise
temp_uclean2         = temp_uclean;
uclean(:,:)          = temp_uclean2(:,:,1); 
uclean(uclean<0)     = 0;

randn('state', data.randseed);   % noisy image
noise                = randn(size(uclean));
noise_std            = 10;  
v0                   = noise_std *noise;    
u0                   = uclean + v0;
u0   = u0/255; uclean = uclean/255;
Err_noise            = norm(u0 - uclean, 'fro')/norm(uclean, 'fro');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% =====New_ElasticaAlgo======== %%%%%%%%%%%%%%%%%%%%%%%%
para.MaxIter         = 5000;   % set parameters maxiter = 5000
para.aa              = 0.1;      % good default: a=0.1, b=0.1, eta =1 
para.bb              = 0.1;     
para.eta             = 1;    
para.tau             = 0.1;    
para.gamma           = 1;     
%para.tol             = 3e-5;  % If lena image, tol = 3e-5; otherwise, tol = 1e-5
Mat_our              = fftMat(u0);
tic
[u_pro, ReErr_our, Err_our, Eng_our]  = New_ElasticaAlg_Denoise_clean(u0, uclean, para, Mat_our);
t_our = toc;

    
%% ======figures shown in the manuscript==========
% ----zooming in a local region-------
% ball [20 50 20 50]; star [20 35 40 60]; square[5 20 5 15]; 
% lena[50 100 80 150] ====If you change the input image, please replace the
% corresponding zooming in locations.
fprintf('Please change the locations in rectangleonimage(*) according to:\n ball [20 50 20 50]; star [20 35 40 60]; square[5 20 5 15]; lena[50 100 80 150] \n')

ent_our=rectangleonimage(u_pro, [20 35 40 60],0.5, 1, 1, 2, 2);
figure,imshow(ent_our); title('Proposed')

ent_u0=rectangleonimage(u0, [20 35 40 60],0.5, 1, 1, 2, 2);
figure,imshow(ent_u0); title('Noisy')

%% =====Results Display========
% -------ReErr plot---------------
figure,
plot(log(ReErr_our), 'b-','linewidth',1.5); 
xlabel('Iter. No.')
ylabel('ReErr (Log)')
legend('Our')

% -------iter.# + time---------------
disp('====Iter#  + Time(s) + AverTime/Per.Iter =======')
disp(['Our',' ',' ',' ',num2str(size(Err_our,2)),' ',' ',' ',' ',num2str(t_our),' ',' ',' ',' ',num2str(t_our/(size(Err_our,2)))]);

%% ========End=====================
profile off
profile viewer
