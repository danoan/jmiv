function [Output, ReErr, Err, Eng] = New_ElasticaAlg_Denoise_clean(u0, uclean, para, Mat_our)
% this function is about the new algorithm for elastica model
% algorithm + clean version
% LJ Deng (UESTC)
% 2018-01-18

%% ====================================
[l1, l2]         = size(u0);
aa               = para.aa;
bb               = para.bb;
eta              = para.eta;
tau              = para.tau;
gamma            = para.gamma;
MaxIter          = para.MaxIter;
tol              = para.tol;

%% ===Initialization======
v                = u0*1;
P1               = v([2:end 1],:) - v([1:end-1 end],:); %forward difference
P2               = v(:,[2:end 1]) - v(:,[1:end-1 end]);
length1          = sqrt(P1.*P1 + P2.*P2);  % |q|
lambda1          = P1./length1;
lambda2          = P2./length1;

%% =====FFT matrices======
A11     = Mat_our.A11;
A12     = Mat_our.A12;
A21     = Mat_our.A21;
A22     = Mat_our.A22;
det_A   = Mat_our.det_A;
B1      = Mat_our.B1;
B2      = Mat_our.B2;

%%%%%%%%%%%Main_Loop%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
relchg1          = 1; 
iter             = 1;
P13_1 = P1; P13_2 = P2;
while relchg1 > tol && iter < MaxIter 
    
    itergamma = P13_1.^2 + P13_2.^2;  % |P13|^2
    gamma     = max(itergamma, sqrt(tau)); %max{|p^{n+1/3}|,sqrt(tau)}; 0.0316
    para.gamma=gamma;
    %% ====For P13 ( P^{n+1/3}) ==============
    px1          = P1;  %  for P13_1
    px2          = aver_y_4pts_x(P2);
    Bnorm1       = sqrt(px1.^2 + px2.^2);% + eps;
    r1           = 1;
    c1           = r1*(tau*aa + tau*bb*(dxc(lambda1) + dy_y_4pts_x(lambda2)).^2); 
    P13_1        = EulerElastica_shrinkage_P(px1, Bnorm1, c1, 1);
    
    px1          = aver_x_4pts_y(P1);  %  for P13_2 
    px2          = P2;
    Bnorm2       = sqrt(px1.^2 + px2.^2);% + eps;
    c2           = r1*(tau*aa + tau*bb*(dx_x_4pts_y(lambda1) + dyc(lambda2)).^2); 
    P13_2        = EulerElastica_shrinkage_P(px2, Bnorm2, c2, 1);
    
    Eng_p13      = energy_p13(para, P1, P2, P13_1,P13_2, lambda1,  lambda2);
    Eng.PEng13(iter) = Eng_p13;
    
    %%====For lambda13 (lambda^{n+1/3})============
    %---iterative version
    %gamma1 = 1;
    [lambda13_1, lambda13_2, ReEr] = iter_lambda13(P13_1, P13_2, lambda1, ...
              lambda2, det_A, A11, A12, A21, A22, tau, bb, gamma, 1); % default: 5  

          
          
    Eng_lam13    = energy_lam13(para, P13_1,P13_2, ...
                  lambda1, lambda2, lambda13_1, lambda13_2);
    Eng.LamEng13(iter) = Eng_lam13;

 
    
    %% ====For P23 ( P^{n+2/3}) & lambda23 (lambda^{n+2/3})======
    
    %===========case 1======
    P23_1_case1  = zeros(l1, l2);
    P23_2_case1  = zeros(l1, l2);
    length2      = sqrt(lambda13_1.^2 + lambda13_2.^2);
    lambda23_1_case1 = lambda13_1./max(1,  length2);
    lambda23_2_case1 = lambda13_2./max(1,  length2);    
    
    [energy1, energy2] = energy_newAlg_23(para, lambda23_1_case1, lambda23_2_case1,...
                             P23_1_case1, P23_2_case1,P13_1,P13_2, lambda13_1, lambda13_2);
    
    %===========case 2======
    Eng.Gam(:,:,iter)   = gamma;
    
    theta  = FixPoint_theta_new(P13_1, P13_2, lambda13_1, lambda13_2, gamma);
    lengnorm            = sqrt((theta.*P13_1 + gamma.*lambda13_1).^2 ...
                              + (theta.*P13_2 + gamma.*lambda13_2).^2 ) + eps; 
                                                 
     lambda23_1_case2  = (theta.*P13_1 +  gamma.*lambda13_1)./lengnorm;
     lambda23_2_case2  = (theta.*P13_2 +  gamma.*lambda13_2)./lengnorm;
     
     P23_1_case2       = theta.*lambda23_1_case2;
     P23_2_case2       = theta.*lambda23_2_case2;
     
     %-----compute error------
     P23c = (P23_1_case2-P13_1).^2+(P23_2_case2-P13_2).^2;
     lambda23c = (lambda23_1_case2-lambda13_1).^2+(lambda23_2_case2-lambda13_2).^2;
     Eng.ans1(iter)   = max(max(abs(P23c))); Eng.ans2(iter) = max(max(abs(gamma.*lambda23c)));
     Eng.ration(:,:,iter) = P23c./lambda23c;
    
     %-----
     lambda23_1_case2(P23_1_case2==0) = lambda23_1_case1(P23_1_case2==0);
     lambda23_2_case2(P23_2_case2==0) = lambda23_2_case1(P23_2_case2==0);

     [energy3, energy4]= energy_newAlg_23(para,lambda23_1_case2, lambda23_2_case2,...
                             P23_1_case2, P23_2_case2,P13_1,P13_2, lambda13_1, lambda13_2);

     %-------- point-by-point decision------------
     index              = find(energy2 < energy4);  % checked! right
     P23_1_case2(index) = P23_1_case1(index);
     P23_2_case2(index) = P23_2_case1(index);
     P23_1              = P23_1_case2;
     P23_2              = P23_2_case2;
     
     lambda23_1_case2(index) = lambda23_1_case1(index);
     lambda23_2_case2(index) = lambda23_2_case1(index);
     lambda23_1              = lambda23_1_case2;  % |lambda23| = 1
     lambda23_2              = lambda23_2_case2;
 
     
     [energy5, energy6]      = energy_newAlg_23(para,lambda23_1_case2, lambda23_2_case2,...
                                    P23_1_case2, P23_2_case2,P13_1,P13_2, lambda13_1, lambda13_2);
     Eng.Eng23(iter)         = energy5;
     
    %% ====For P33 ( P^{n+3/3})====================
    ww        = v;
    fft_left  = B1 + B2 - tau*eta ; %+ eps
    fft_right = fftn(dxc2(P23_1) + dyc2(P23_2) - tau*eta*u0);
    v         = real(ifftn(fft_right./fft_left));   
    v(v < 0)   = 0;
    v(v > 1)   = 1; 
    
    P33_1    = dxf(v); %forward difference
    P33_2    = dyf(v);
    
    Eng.Eng33(iter) = energy_33(para, P23_1,P23_2, P33_1,P33_2, u0, v);

    %%====For lambda33 (lambda^{n+3/3})============   
    lambda33_1 = lambda23_1;
    lambda33_2 = lambda23_2;
    
    %% ====Update P and lambda===================
    lambda1    = lambda33_1;
    lambda2    = lambda33_2;
    P1         = P33_1;
    P2         = P33_2;

    Eng.Engtotal(iter) = energy_total(para, u0, v); 
      
    %% ====Compute ReError===================
    relchg     = norm(v - uclean,'fro')/norm(uclean,'fro');
    Err(iter)  = relchg;
    
    relchg1    = norm(v - ww,'fro')/norm(v,'fro'); % relative error
    ReErr(iter) = relchg1;
            
    iter       = iter +1;

end
    Output     = v;
end


%%%%%%%%%%%%%%%%%%%%%%%%%BELOW%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%% Subfunctions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function v=aver_y_4pts_x(u)
%     u(i+1,j)      + u(i+1,j-1)               +u(i,j)+u(i,j-1)  
v = ( u([2:end 1],:)+u([2:end 1],[end 1:end-1])+u(:,:)+u(:,[end 1:end-1]) )/4;
end

function v=dxc(u)
%     u(i+1,j)      -u(i-1,j)
v = ( u([2:end 1],:)-u([end 1:end-1],:) )/2;
end

function v=dy_y_4pts_x(u)
%     u(i+1,j)      -u(i+1,j-1)                +u(i,j)-u(i,j-1)
v = ( u([2:end 1],:)-u([2:end 1],[end 1:end-1])+u(:,:)-u(:,[end 1:end-1]) )/2;
end

function P = EulerElastica_shrinkage_P(B,Bnorm,coe_P,r2)
   P = B*0;
   b = 1-coe_P./( r2*Bnorm);
   index3 = find(b>0);
   P(index3) = b(index3).*B(index3);
end

function v=aver_x_4pts_y(u)
%     u(i,j) + u(i,j+1)       + u(i-1,j)           + u(i-1,j+1)
v = ( u(:,:) + u(:,[2:end 1]) + u([end 1:end-1],:) + u([end 1:end-1],[2:end 1]) )/4;
end

function v=dx_x_4pts_y(u)
%     u(i,j)-u(i-1,j)          + u(i,j+1)      -u(i-1,j+1)
v = ( u(:,:)-u([end 1:end-1],:)+ u(:,[2:end 1])-u([end 1:end-1],[2:end 1]) )/2;
end

function v=dyc(u)
%     u(i,j+1)      -u(i,j-1)
v = ( u(:,[2:end 1])-u(:,[end 1:end-1]) )/2;
end

function v=dxc2(u)
%   u(i,j) - u(i-1,j)
v = u(:,:) - u([end 1:end-1],:);
end

function v=dyc2(u)
%   u(i,j) - u(i,j-1)
v = u(:,:) - u(:,[end 1:end-1]);
end

function v=dxf(u)
%   u(i+1,j)       - u(i,j)
v = u([2:end 1],:) - u(:,:);
end

function v=dyf(u)
%   u(i,j+1)       - u(i,j)
v = u(:,[2:end 1]) - u(:,:);
end

function v=dxb(u)
%   u(i,j) - u(i-1,j)
v = u(:,:) - u([end 1:end-1],:);
end

function v=dyb(u)
%   u(i,j) - u(i,j-1)
v = u(:,:) - u(:,[end 1:end-1]);
end


function [energy] = energy_p13(para, P1, P2, P13_1,P13_2, lambda1,  lambda2)
% Engergy equation: Eq. (15)
div_n      = dxb(lambda1)+dyb(lambda2);
norm_P     = sqrt(P13_1.^2+P13_2.^2);
temp_mid   = (para.aa+para.bb*div_n.^2).*norm_P;
normPP     = (P13_1-P1).^2+(P13_2-P2).^2;
energy     = 0.5*(1/para.tau)*sum(normPP(:)) + sum( temp_mid(:) );
end


function [energy1, energy2] = energy_newAlg_23(para,N1,N2,P1,P2,P13_1,P13_2, lambda13_1, lambda13_2)
% Engergy equation: Eq. (20)
% energy1: total energy of Eq.(20)
% energy2: point-by-point energy of Eq.(20)
norm_P   =  ((P1 - P13_1).^2 + (P2 - P13_2).^2)/(2*para.tau);
norm_lambda  =  para.gamma.*((N1 - lambda13_1).^2 + (N2 - lambda13_2).^2)/(2*para.tau);
energy1 = sum(norm_P(:)) + sum(norm_lambda(:)); % total
energy2 = norm_P + norm_lambda; % point-by-point energy
end


function energy = energy_lam13(para, P13_1,P13_2, lambda1, lambda2, lambda13_1,  lambda13_2)
% Engergy equation: Eq. (12) 2nd one
div_n    = dxb(lambda13_1)+dyb(lambda13_2);
norm_P   = sqrt(P13_1.^2+P13_2.^2);  % |q|
temp_mid = (para.aa+para.bb*div_n.^2).*norm_P; % a + b*div_n
normPP   = para.gamma.*((lambda13_1-lambda1).^2+(lambda13_2-lambda2).^2);
energy   = 0.5*(1/para.tau)*sum(normPP(:)) + sum( temp_mid(:) );
end

function [energy] = energy_33(para, P23_1,P23_2, P33_1,P33_2, u0, v)
% Engergy equation: Eq. (36)
norm_P = (u0 - v).^2;
normPP     = (P33_1 - P23_1).^2 + (P33_2 - P23_2).^2;
energy = 0.5*(1/para.tau)*sum(normPP(:)) + 0.5*(para.eta)*sum(norm_P(:));
end

% function energy  = energy_total(para, P33_1,P33_2, lambda33_1,  lambda33_2, u0, v)
% % Engergy equation: Eq. (4)
% div_n     = dxb(lambda33_1)+dyb(lambda33_2); % div.(lambda33)
% norm_P    = sqrt(P33_1.^2+P33_2.^2);  % |q|
% temp_mid  = (para.aa+para.bb*div_n.^2).*norm_P;
% norm2     = (u0 - v).^2;
% energy    = 0.5*para.eta*sum(norm2(:)) + sum( temp_mid(:) );
% end

function energy  = energy_total(para, u0, v)
% Engergy equation: Eq. (1)
norm_P    = sqrt(dxf(v).^2 + dyf(v).^2)+eps;  % |grad(v)|=|p|
px1       = dxf(v)./norm_P; % grad_x(v)/|grad(v)|
px2       = dyf(v)./norm_P; % grad_y(v)/|grad(v)|
div_n     = dxc2(px1) + dyc2(px2); % div.(p/|p|)
temp_mid  = (para.aa+para.bb*div_n.^2).*norm_P;
norm2     = (u0 - v).^2;
energy    = 0.5*para.eta*sum(norm2(:)) + sum( temp_mid(:) );
% norm2     = norm(v-u0,'fro')^2;
% energy    = 0.5*para.eta*norm2 + sum( temp_mid(:) );

end


function [energy, energy_J1, energy_J2, energy_c, energy_bc, energy_t, energy_at, div_n, norm_P] = ...
    energy_total_denoise(para, P33_1,P33_2, lambda33_1,  lambda33_2, u0, v)
% Engergy equation: Eq. (4)
div_n     = dxb(lambda33_1)+dyb(lambda33_2); % div.(lambda33)
%div_n     = lambda33_1+lambda33_2; % div.(lambda33)

norm_P    = sqrt(P33_1.^2+P33_2.^2);  % |q|
temp_mid  = (para.aa+para.bb*div_n.^2).*norm_P;  % L2
%temp_mid  = (para.aa+para.bb*div_n).*norm_P;  % L1
norm2     = (u0 - v).^2;

energyc = (div_n.^2).*norm_P;  % energy of curvature: L2
%energyc = (div_n).*norm_P;  % energy of curvature: L1

energy_c = sum(energyc(:));
energybc = (para.bb*div_n.^2).*norm_P; % L2
%energybc = (para.bb*div_n).*norm_P; % L1
energy_bc = sum(energybc(:));

energyt =  norm_P;  % energy of TV
energy_t = sum(energyt(:));
energyat = para.aa*norm_P;
energy_at = sum(energyat(:));

energy_J1 = sum( temp_mid(:) );
energy_J2 = 0.5*para.eta*sum(norm2(:));

energy    = energy_J2 + energy_J1;


end

%-------------------------------------------------
function [lambda13_1, lambda13_2, ReEr] = iter_lambda13(P13_1, P13_2, lambda1, ...
              lambda2, det_A, A11, A12, A21, A22, tau, bb, gamma, iterNum)
% Eq.(47)          
    lambda_fix1  = lambda1;
    lambda_fix2  = lambda2;    
for k            = 1:iterNum                 
    temp_coe     = 2*tau*bb*sqrt(aver_xb(P13_1).^2+aver_yb(P13_2).^2); % 2*tau*b*|A|_{i,j}(P)
    c_N          = max(max(temp_coe));   % c = max{2*tau*b*|A|_{i,j}(P)}
    diff_c_N     = c_N - temp_coe;    % c - 2*tau*b*|A|_{i,j}(P)
    
    temp_div     = diff_c_N.*( dxb(lambda1)+dyb(lambda2) ); % (c - 2*tau*b*|A|_{i,j}(P)).*div(lambda)
    f1           = fftn( gamma.*lambda_fix1 -  dxf(temp_div) );% r*lambda1  - (temp_div(i+1,j)-temp_div(i,j))
    f2           = fftn( gamma.*lambda_fix2 -  dyf(temp_div) );% r*lambda2  - (temp_div(i,j+1)-temp_div(i,j))

    tempA11      = gamma - c_N*A11;
    tempA12      =       - c_N*A12;
    tempA21      =       - c_N*A21;
    tempA22      = gamma - c_N*A22;
    det_tempA    = gamma.*gamma - 2*c_N.*gamma.*det_A; 
           
    ff1          = ( tempA22.*f1 - tempA12.*f2)./det_tempA;
    ff2          = (-tempA21.*f1 + tempA11.*f2)./det_tempA;

    lam13_1      = real(ifftn(ff1));   % lambda_{1}^{n+1/3}
    lam13_2      = real(ifftn(ff2));   % lambda_{2}^{n+1/3}

    ReEr(k)      = norm(lam13_1 - lambda1, 'fro')/norm(lambda1, 'fro');
    % ====update======
    lambda1      = lam13_1;
    lambda2      = lam13_2;    
   
end
    lambda13_1   = lam13_1;
    lambda13_2   = lam13_2;
end

%%%%%%%%%%%%%%%%%%subfunctions%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
function v=aver_xb(u)
%    u(i,j) + u(i-1,j)
v = (u(:,:) + u([end 1:end-1],:))/2;
end

function v=aver_yb(u)
%    u(i,j) + u(i,j-1)
v = (u(:,:) + u(:,[end 1:end-1]))/2;
end


